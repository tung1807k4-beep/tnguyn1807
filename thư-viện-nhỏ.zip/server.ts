import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database(path.join(__dirname, "library.db"));

// Initialize Database
try {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      phone TEXT NOT NULL,
      cccd TEXT UNIQUE NOT NULL,
      role TEXT DEFAULT 'user',
      password TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId INTEGER NOT NULL,
      mediaUrl TEXT NOT NULL,
      description TEXT,
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (userId) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS books (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      author TEXT NOT NULL,
      description TEXT,
      coverUrl TEXT,
      category TEXT,
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId INTEGER NOT NULL,
      message TEXT NOT NULL,
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (userId) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS borrowed_books (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId INTEGER NOT NULL,
      bookId INTEGER NOT NULL,
      status TEXT DEFAULT 'pending', -- pending, borrowed, returning, returned
      borrowDate DATETIME DEFAULT CURRENT_TIMESTAMP,
      returnDate DATETIME,
      FOREIGN KEY (userId) REFERENCES users(id),
      FOREIGN KEY (bookId) REFERENCES books(id)
    );
  `);

  // Migration: Add pdfUrl to books if it doesn't exist
  // Removed pdfUrl functionality
} catch (err) {
  console.error("Database initialization error:", err);
}

// Seed Admin and Initial Data
try {
  const adminExists = db.prepare("SELECT * FROM users WHERE role = 'admin'").get();
  if (!adminExists) {
    db.prepare("INSERT INTO users (name, email, phone, cccd, role, password) VALUES (?, ?, ?, ?, ?, ?)")
      .run("Quản trị viên", "admin@library.com", "0967068565", "024204006849", "admin", "admin123");
    
    // Seed virtual members
    const virtualUsers = [
      { name: "Nguyễn Văn A", email: "vana@gmail.com", phone: "0901234567", cccd: "001203004567", password: "user123" },
      { name: "Trần Thị B", email: "thib@gmail.com", phone: "0907654321", cccd: "001203008901", password: "user123" },
      { name: "Lê Văn C", email: "vanc@gmail.com", phone: "0912345678", cccd: "001203001234", password: "user123" }
    ];
    const insertUser = db.prepare("INSERT INTO users (name, email, phone, cccd, password) VALUES (?, ?, ?, ?, ?)");
    virtualUsers.forEach(u => insertUser.run(u.name, u.email, u.phone, u.cccd, u.password));

    // Seed some books
    const books = [
      { title: "Đắc Nhân Tâm", author: "Dale Carnegie", category: "Kỹ năng", coverUrl: "https://picsum.photos/seed/dnt/400/600" },
      { title: "Nhà Giả Kim", author: "Paulo Coelho", category: "Tiểu thuyết", coverUrl: "https://picsum.photos/seed/ngk/400/600" },
      { title: "Số Đỏ", author: "Vũ Trọng Phụng", category: "Văn học VN", coverUrl: "https://picsum.photos/seed/sodo/400/600" },
      { title: "Mắt Biếc", author: "Nguyễn Nhật Ánh", category: "Lãng mạn", coverUrl: "https://picsum.photos/seed/matbiec/400/600" }
    ];
    const insertBook = db.prepare("INSERT INTO books (title, author, category, coverUrl) VALUES (?, ?, ?, ?)");
    books.forEach(book => insertBook.run(book.title, book.author, book.category, book.coverUrl));

    // Seed some posts with quotes
    const seedPosts = [
      { userId: 2, mediaUrl: "https://picsum.photos/seed/quote1/1080/1920", description: "Hạnh phúc không phải là điểm đến, mà là hành trình chúng ta đang đi. - Trích 'Nhà Giả Kim'" },
      { userId: 3, mediaUrl: "https://picsum.photos/seed/quote2/1080/1920", description: "Đừng bao giờ từ bỏ ước mơ của mình. Hãy lắng nghe trái tim mình dẫn lối." },
      { userId: 4, mediaUrl: "https://picsum.photos/seed/quote3/1080/1920", description: "Có những người đi qua đời ta để lại những kỷ niệm không thể nào quên. - Mắt Biếc" }
    ];
    const insertPost = db.prepare("INSERT INTO posts (userId, mediaUrl, description) VALUES (?, ?, ?)");
    seedPosts.forEach(p => insertPost.run(p.userId, p.mediaUrl, p.description));
  }
} catch (err) {
  console.error("Seeding error:", err);
}

async function startServer() {
  const app = express();
  
  // Health check
  app.get("/health", (req, res) => res.send("OK"));

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // Auth Routes
  app.post("/api/register", (req, res) => {
    const { name, email, phone, cccd, password } = req.body;
    console.log(`Register attempt: ${email}`);
    try {
      const result = db.prepare("INSERT INTO users (name, email, phone, cccd, password) VALUES (?, ?, ?, ?, ?)")
        .run(name, email, phone, cccd, password);
      const userId = result.lastInsertRowid;
      
      db.prepare("INSERT INTO notifications (userId, message) VALUES (?, ?)")
        .run(userId, "Chúc mừng! Bạn đã đăng ký tài khoản thành công.");

      res.json({ id: userId, name, email, role: 'user', phone, cccd });
    } catch (error: any) {
      console.error("Register error:", error);
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/login", (req, res) => {
    const { email, password } = req.body;
    console.log(`Login attempt: ${email}`);
    try {
      const user = db.prepare("SELECT * FROM users WHERE email = ? AND password = ?").get(email, password) as any;
      if (user) {
        const roleName = user.role === 'admin' ? 'Quản trị viên' : 'Thành viên';
        db.prepare("INSERT INTO notifications (userId, message) VALUES (?, ?)")
          .run(user.id, `Bạn đã đăng nhập thành công với tư cách ${roleName}.`);
        
        res.json({ id: user.id, name: user.name, email: user.email, role: user.role, phone: user.phone, cccd: user.cccd });
      } else {
        res.status(401).json({ error: "Thông tin đăng nhập không chính xác" });
      }
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Lỗi máy chủ" });
    }
  });

  // Notification Routes
  app.get("/api/notifications/:userId", (req, res) => {
    try {
      const notifications = db.prepare("SELECT * FROM notifications WHERE userId = ? ORDER BY createdAt DESC").all(req.params.userId);
      res.json(notifications);
    } catch (error) {
      console.error("Fetch notifications error:", error);
      res.status(500).json({ error: "Lỗi máy chủ" });
    }
  });

  // User Routes
  app.get("/api/users", (req, res) => {
    try {
      const users = db.prepare("SELECT id, name, email, phone, cccd, role FROM users").all();
      res.json(users);
    } catch (error) {
      console.error("Fetch users error:", error);
      res.status(500).json({ error: "Lỗi máy chủ" });
    }
  });

  // Post Routes
  app.get("/api/posts", (req, res) => {
    try {
      const posts = db.prepare(`
        SELECT posts.*, users.name as userName 
        FROM posts 
        JOIN users ON posts.userId = users.id 
        ORDER BY createdAt DESC
      `).all();
      res.json(posts);
    } catch (error) {
      console.error("Fetch posts error:", error);
      res.status(500).json({ error: "Lỗi máy chủ" });
    }
  });

  app.post("/api/posts", (req, res) => {
    const { userId, mediaUrl, description } = req.body;
    try {
      const result = db.prepare("INSERT INTO posts (userId, mediaUrl, description) VALUES (?, ?, ?)")
        .run(userId, mediaUrl, description);
      res.json({ id: result.lastInsertRowid });
    } catch (error) {
      console.error("Create post error:", error);
      res.status(500).json({ error: "Lỗi máy chủ" });
    }
  });

  // Book Routes
  app.get("/api/books", (req, res) => {
    const { q } = req.query;
    try {
      let books;
      if (q) {
        books = db.prepare("SELECT * FROM books WHERE title LIKE ? OR author LIKE ?")
          .all(`%${q}%`, `%${q}%`);
      } else {
        books = db.prepare("SELECT * FROM books").all();
      }
      res.json(books);
    } catch (error) {
      console.error("Fetch books error:", error);
      res.status(500).json({ error: "Lỗi máy chủ" });
    }
  });

  app.post("/api/books", (req, res) => {
    const { title, author, description, coverUrl, category } = req.body;
    try {
      const result = db.prepare("INSERT INTO books (title, author, description, coverUrl, category) VALUES (?, ?, ?, ?, ?)")
        .run(title, author, description, coverUrl, category);
      res.json({ id: result.lastInsertRowid });
    } catch (err) {
      console.error("Error saving book:", err);
      res.status(500).json({ error: "Không thể lưu sách" });
    }
  });

  app.delete("/api/books/:id", (req, res) => {
    try {
      db.prepare("DELETE FROM books WHERE id = ?").run(req.params.id);
      res.json({ success: true });
    } catch (err) {
      console.error("Error deleting book:", err);
      res.status(500).json({ error: "Không thể xóa sách" });
    }
  });

  app.get("/api/books/suggested", (req, res) => {
    try {
      const books = db.prepare("SELECT * FROM books ORDER BY RANDOM() LIMIT 4").all();
      res.json(books);
    } catch (err) {
      res.status(500).json({ error: "Lỗi khi tải sách gợi ý" });
    }
  });

  // Borrowing Routes
  app.post("/api/borrow", (req, res) => {
    const { userId, bookId } = req.body;
    try {
      const result = db.prepare("INSERT INTO borrowed_books (userId, bookId) VALUES (?, ?)")
        .run(userId, bookId);
      
      // Notify Admin (userId 1 is usually admin in this setup)
      db.prepare("INSERT INTO notifications (userId, message) VALUES (?, ?)")
        .run(1, `Có yêu cầu mượn sách mới từ người dùng ID ${userId}.`);
        
      res.json({ id: result.lastInsertRowid });
    } catch (error) {
      console.error("Borrow error:", error);
      res.status(500).json({ error: "Lỗi khi yêu cầu mượn sách" });
    }
  });

  app.get("/api/borrowed/:userId", (req, res) => {
    try {
      const borrowed = db.prepare(`
        SELECT borrowed_books.*, books.title, books.author, books.coverUrl 
        FROM borrowed_books 
        JOIN books ON borrowed_books.bookId = books.id 
        WHERE borrowed_books.userId = ?
        ORDER BY borrowDate DESC
      `).all(req.params.userId);
      res.json(borrowed);
    } catch (error) {
      console.error("Fetch borrowed error:", error);
      res.status(500).json({ error: "Lỗi khi tải danh sách mượn" });
    }
  });

  app.get("/api/admin/borrowed", (req, res) => {
    try {
      const borrowed = db.prepare(`
        SELECT borrowed_books.*, books.title, users.name as userName, users.email as userEmail
        FROM borrowed_books 
        JOIN books ON borrowed_books.bookId = books.id 
        JOIN users ON borrowed_books.userId = users.id
        WHERE status != 'returned'
        ORDER BY borrowDate DESC
      `).all();
      res.json(borrowed);
    } catch (error) {
      console.error("Fetch admin borrowed error:", error);
      res.status(500).json({ error: "Lỗi khi tải danh sách quản lý mượn" });
    }
  });

  app.put("/api/borrowed/:id/status", (req, res) => {
    const { status } = req.body;
    try {
      const borrow = db.prepare("SELECT * FROM borrowed_books WHERE id = ?").get(req.params.id) as any;
      if (!borrow) return res.status(404).json({ error: "Không tìm thấy thông tin mượn" });

      db.prepare("UPDATE borrowed_books SET status = ? WHERE id = ?").run(status, req.params.id);
      
      let message = "";
      if (status === 'borrowed') message = "Yêu cầu mượn sách của bạn đã được phê duyệt. Hãy đến thư viện nhận sách.";
      if (status === 'returned') message = "Sách đã được trả thành công. Cảm ơn bạn!";
      if (status === 'returning') message = "Bạn đã gửi yêu cầu trả sách. Vui lòng chờ quản trị viên phê duyệt.";

      db.prepare("INSERT INTO notifications (userId, message) VALUES (?, ?)")
        .run(borrow.userId, message);

      res.json({ success: true });
    } catch (error) {
      console.error("Update borrow status error:", error);
      res.status(500).json({ error: "Lỗi khi cập nhật trạng thái" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  const PORT = 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
    console.log("Environment:", process.env.NODE_ENV || "development");
  });
}

console.log("Starting server initialization...");
startServer().catch(err => {
  console.error("Failed to start server:", err);
});

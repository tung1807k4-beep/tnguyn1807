export enum UserRole {
  ADMIN = 'admin',
  USER = 'user'
}

export interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
  cccd: string;
  role: UserRole;
}

export interface Post {
  id: number;
  userId: number;
  userName: string;
  mediaUrl: string;
  description: string;
  createdAt: string;
}

export interface Book {
  id: number;
  title: string;
  author: string;
  description: string;
  coverUrl: string;
  category: string;
  createdAt: string;
}

export interface Notification {
  id: number;
  userId: number;
  message: string;
  createdAt: string;
}

export interface BorrowedBook {
  id: number;
  userId: number;
  bookId: number;
  status: 'pending' | 'borrowed' | 'returning' | 'returned';
  borrowDate: string;
  returnDate?: string;
  title?: string;
  author?: string;
  coverUrl?: string;
  userName?: string;
  userEmail?: string;
}

import React, { useState, useEffect, FormEvent, useRef } from 'react';
import { User, UserRole, Post, Book, Notification as AppNotification, BorrowedBook } from './types';
import { 
  Home as HomeIcon, 
  Library as LibraryIcon, 
  PlusSquare, 
  Mail, 
  User as UserIcon,
  Search,
  LogOut,
  Plus,
  ShieldCheck,
  Camera,
  Image as ImageIcon,
  Bell,
  Settings,
  ChevronRight,
  FileText,
  X,
  Trash2,
  Sparkles,
  BookOpen,
  Clock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";

// --- Utilities ---

const fetchWithRetry = async (url: string, options: RequestInit = {}, retries = 3, backoff = 1000): Promise<Response> => {
  try {
    const response = await fetch(url, options);
    if (response.status === 429 && retries > 0) {
      console.warn(`Rate limit exceeded. Retrying in ${backoff}ms... (${retries} retries left)`);
      await new Promise(resolve => setTimeout(resolve, backoff));
      return fetchWithRetry(url, options, retries - 1, backoff * 2);
    }
    return response;
  } catch (error) {
    if (retries > 0) {
      await new Promise(resolve => setTimeout(resolve, backoff));
      return fetchWithRetry(url, options, retries - 1, backoff * 2);
    }
    throw error;
  }
};

// --- Components ---

const Auth = ({ onLogin }: { onLogin: (user: User) => void }) => {
  const [isRegister, setIsRegister] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    cccd: '',
    password: ''
  });
  const [error, setError] = useState('');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    const endpoint = isRegister ? '/api/register' : '/api/login';
    try {
      const res = await fetchWithRetry(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await res.json();
      if (res.ok) {
        onLogin(data);
      } else {
        setError(data.error || 'Đã có lỗi xảy ra');
      }
    } catch (err) {
      setError('Không thể kết nối đến máy chủ');
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold tracking-tighter">THƯ VIỆN NHỎ</h1>
          <p className="text-zinc-400 mt-2">{isRegister ? 'Tạo tài khoản mới' : 'Chào mừng bạn quay lại'}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegister && (
            <>
              <input
                type="text"
                placeholder="Họ và tên"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-4 focus:outline-none focus:border-white transition-colors"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
                required
              />
              <input
                type="text"
                placeholder="Số điện thoại"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-4 focus:outline-none focus:border-white transition-colors"
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                required
              />
              <input
                type="text"
                placeholder="Số CCCD"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-4 focus:outline-none focus:border-white transition-colors"
                value={formData.cccd}
                onChange={e => setFormData({ ...formData, cccd: e.target.value })}
                required
              />
            </>
          )}
          <input
            type="email"
            placeholder="Email"
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-4 focus:outline-none focus:border-white transition-colors"
            value={formData.email}
            onChange={e => setFormData({ ...formData, email: e.target.value })}
            required
          />
          <input
            type="password"
            placeholder="Mật khẩu"
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-4 focus:outline-none focus:border-white transition-colors"
            value={formData.password}
            onChange={e => setFormData({ ...formData, password: e.target.value })}
            required
          />
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <button
            type="submit"
            className="w-full bg-white text-black font-bold py-4 rounded-xl hover:bg-zinc-200 transition-colors"
          >
            {isRegister ? 'Đăng ký' : 'Đăng nhập'}
          </button>
        </form>

        <div className="text-center space-y-4">
          <button
            onClick={() => setIsRegister(!isRegister)}
            className="text-zinc-400 hover:text-white text-sm"
          >
            {isRegister ? 'Đã có tài khoản? Đăng nhập' : "Chưa có tài khoản? Đăng ký"}
          </button>
          {!isRegister && (
            <div className="pt-4 border-t border-zinc-900">
              <p className="text-[10px] text-zinc-600 uppercase tracking-widest">Tài khoản Admin Demo</p>
              <p className="text-xs text-zinc-500">admin@library.com / admin123</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const Feed = ({ user }: { user: User | null }) => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchPosts = () => {
    setLoading(true);
    fetchWithRetry('/api/posts')
      .then(async res => {
        if (!res.ok) {
          const text = await res.text();
          throw new Error(`Lỗi khi tải bài viết: ${res.status} ${text}`);
        }
        return res.json();
      })
      .then(data => {
        setPosts(data);
        setLoading(false);
      })
      .catch(err => {
        console.error("Fetch posts error:", err);
        setError('Không thể tải bài viết. Vui lòng thử lại sau.');
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  if (loading) return <div className="h-full flex items-center justify-center bg-black text-white">Đang tải...</div>;
  if (error) return <div className="h-full flex items-center justify-center bg-black text-white p-6 text-center">{error}</div>;

  return (
    <div className="h-full overflow-y-scroll snap-y snap-mandatory bg-black relative">
      {posts.length === 0 ? (
        <div className="h-full flex flex-col items-center justify-center text-zinc-500 p-6 text-center">
          <ImageIcon size={64} className="mb-4 opacity-20" />
          <p className="text-lg">Chưa có bài viết nào</p>
          <p className="text-sm mt-2">Hãy là người đầu tiên chia sẻ khoảnh khắc đọc sách!</p>
        </div>
      ) : posts.map(post => (
        <div key={post.id} className="h-full w-full snap-start relative flex flex-col justify-end p-6">
          {post.mediaUrl && post.mediaUrl.startsWith('data:video/') ? (
            <video 
              src={post.mediaUrl} 
              className="absolute inset-0 w-full h-full object-cover z-0" 
              autoPlay 
              loop 
              muted 
              playsInline
            />
          ) : post.mediaUrl ? (
            <img 
              src={post.mediaUrl} 
              className="absolute inset-0 w-full h-full object-cover z-0" 
              alt="Nội dung bài đăng"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="absolute inset-0 bg-zinc-900 flex items-center justify-center">
              <ImageIcon size={48} className="text-zinc-800" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent z-10" />
          
          <div className="relative z-20 space-y-3 max-w-[85%] mb-12">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-zinc-800 rounded-full flex items-center justify-center border border-white/20">
                <UserIcon size={16} />
              </div>
              <h3 className="font-bold text-lg">@{post.userName}</h3>
            </div>
            <p className="text-sm text-zinc-100 leading-relaxed drop-shadow-md">{post.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

const GeminiAssistant = () => {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAsk = async () => {
    if (!prompt) return;
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const result = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Bạn là một trợ lý thư viện nhiệt tình. Người dùng hỏi: ${prompt}. Hãy trả lời ngắn gọn, hữu ích bằng tiếng Việt về sách, việc đọc sách hoặc các dịch vụ thư viện.`
      });
      setResponse(result.text || "Xin lỗi, tôi không thể tạo câu trả lời lúc này.");
    } catch (err) {
      setResponse("Lỗi kết nối với trợ lý AI.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-4 mb-8">
      <div className="flex items-center space-x-2 mb-3">
        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
        <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Trợ lý Sách AI</h3>
      </div>
      <div className="flex space-x-2">
        <input
          type="text"
          placeholder="Hỏi tôi bất cứ điều gì về sách..."
          className="flex-1 bg-black border border-zinc-800 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-emerald-500 transition-colors"
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleAsk()}
        />
        <button 
          onClick={handleAsk}
          disabled={loading}
          className="bg-emerald-500 text-black px-4 py-2 rounded-xl text-sm font-bold hover:bg-emerald-400 disabled:opacity-50"
        >
          {loading ? '...' : 'Hỏi'}
        </button>
      </div>
      {response && (
        <motion.div 
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mt-4 p-3 bg-black/50 rounded-xl border border-zinc-800/50 text-sm text-zinc-300 leading-relaxed"
        >
          {response}
        </motion.div>
      )}
    </div>
  );
};

const Library = ({ user }: { user: User }) => {
  const [books, setBooks] = useState<Book[]>([]);
  const [search, setSearch] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newBook, setNewBook] = useState({
    title: '',
    author: '',
    description: '',
    category: '',
    coverUrl: ''
  });

  const fetchBooks = (query = '') => {
    fetchWithRetry(`/api/books?q=${query}`)
      .then(async res => {
        if (!res.ok) {
          const text = await res.text();
          throw new Error(`Lỗi khi tải sách: ${res.status} ${text}`);
        }
        return res.json();
      })
      .then(setBooks)
      .catch(err => console.error("Fetch books error:", err));
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchBooks(search);
    }, 500);
    return () => clearTimeout(timer);
  }, [search]);

  const handleAddBook = async (e: FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetchWithRetry('/api/books', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newBook)
      });
      if (res.ok) {
        alert("Đã lưu sách thành công!");
        setShowAddForm(false);
        setNewBook({ title: '', author: '', description: '', category: '', coverUrl: '' });
        fetchBooks();
      } else {
        const data = await res.json();
        alert(data.error || "Lỗi khi lưu sách");
      }
    } catch (err) {
      alert("Lỗi kết nối khi lưu sách");
    }
  };

  const handleDeleteBook = async (id: number) => {
    if (!confirm("Bạn có chắc chắn muốn xóa cuốn sách này?")) return;
    try {
      const res = await fetchWithRetry(`/api/books/${id}`, { method: 'DELETE' });
      if (res.ok) {
        alert("Đã xóa sách thành công!");
        fetchBooks();
      } else {
        const data = await res.json();
        alert(data.error || "Lỗi khi xóa sách");
      }
    } catch (err) {
      alert("Lỗi kết nối khi xóa sách");
    }
  };

  const handleBorrowBook = async (bookId: number) => {
    try {
      const res = await fetchWithRetry('/api/borrow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, bookId })
      });
      if (res.ok) {
        alert("Yêu cầu mượn sách đã được gửi! Vui lòng chờ quản trị viên phê duyệt.");
      } else {
        const data = await res.json();
        alert(data.error || "Lỗi khi yêu cầu mượn sách");
      }
    } catch (err) {
      alert("Lỗi kết nối khi yêu cầu mượn sách");
    }
  };

  return (
    <div className="h-full bg-black text-white p-6 overflow-y-auto pb-24">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Thư viện</h1>
        <div className="flex items-center space-x-3">
          {user.role === UserRole.ADMIN && (
            <div className="flex items-center space-x-2">
              <button 
                onClick={() => setShowAddForm(!showAddForm)}
                className="bg-emerald-500 text-black p-2 rounded-lg hover:bg-emerald-400 transition-colors"
              >
                <Plus size={20} />
              </button>
            </div>
          )}
          {user.role === UserRole.ADMIN && (
            <ShieldCheck className="text-emerald-500" />
          )}
        </div>
      </div>

      <AnimatePresence>
        {showAddForm && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 mb-8"
          >
            <h2 className="text-lg font-bold mb-4">Thêm sách mới</h2>
            <form onSubmit={handleAddBook} className="space-y-4">
              <input
                type="text"
                placeholder="Tiêu đề sách"
                className="w-full bg-black border border-zinc-800 rounded-xl p-3 focus:outline-none focus:border-emerald-500"
                value={newBook.title}
                onChange={e => setNewBook({...newBook, title: e.target.value})}
                required
              />
              <input
                type="text"
                placeholder="Tác giả"
                className="w-full bg-black border border-zinc-800 rounded-xl p-3 focus:outline-none focus:border-emerald-500"
                value={newBook.author}
                onChange={e => setNewBook({...newBook, author: e.target.value})}
                required
              />
              <input
                type="text"
                placeholder="Thể loại"
                className="w-full bg-black border border-zinc-800 rounded-xl p-3 focus:outline-none focus:border-emerald-500"
                value={newBook.category}
                onChange={e => setNewBook({...newBook, category: e.target.value})}
                required
              />
              <input
                type="text"
                placeholder="URL ảnh bìa (hoặc để trống)"
                className="w-full bg-black border border-zinc-800 rounded-xl p-3 focus:outline-none focus:border-emerald-500"
                value={newBook.coverUrl}
                onChange={e => setNewBook({...newBook, coverUrl: e.target.value || `https://picsum.photos/seed/${Math.random()}/400/600`})}
              />
              <textarea
                placeholder="Mô tả sách"
                className="w-full bg-black border border-zinc-800 rounded-xl p-3 focus:outline-none focus:border-emerald-500 h-24"
                value={newBook.description}
                onChange={e => setNewBook({...newBook, description: e.target.value})}
              />
              <div className="flex space-x-3">
                <button 
                  type="submit"
                  className="flex-1 bg-emerald-500 text-black font-bold py-3 rounded-xl hover:bg-emerald-400"
                >
                  Lưu sách
                </button>
                <button 
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-zinc-800 text-white font-bold py-3 rounded-xl hover:bg-zinc-700"
                >
                  Hủy
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <GeminiAssistant />

      <div className="relative mb-8">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
        <input
          type="text"
          placeholder="Tìm kiếm sách hoặc tác giả..."
          className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-white transition-colors"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        {books.map(book => (
          <motion.div 
            key={book.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-zinc-900 rounded-2xl overflow-hidden border border-zinc-800"
          >
            {book.coverUrl ? (
              <img 
                src={book.coverUrl} 
                className="w-full aspect-[2/3] object-cover" 
                alt={book.title}
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-full aspect-[2/3] bg-zinc-800 flex items-center justify-center">
                <LibraryIcon size={32} className="text-zinc-700" />
              </div>
            )}
            <div className="p-3">
              <h3 className="font-bold text-sm truncate">{book.title}</h3>
              <p className="text-xs text-zinc-400 truncate">{book.author}</p>
              <div className="flex items-center justify-between mt-2">
                <span className="px-2 py-0.5 bg-zinc-800 rounded text-[10px] uppercase tracking-wider text-zinc-500">
                  {book.category}
                </span>
                <button 
                  onClick={() => handleBorrowBook(book.id)}
                  className="text-[10px] font-bold text-blue-500 hover:text-blue-400 flex items-center space-x-1"
                >
                  <BookOpen size={12} />
                  <span>Mượn sách</span>
                </button>
                {user.role === UserRole.ADMIN && (
                  <button 
                    onClick={() => handleDeleteBook(book.id)}
                    className="text-zinc-500 hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

const Profile = ({ user, onLogout }: { user: User, onLogout: () => void }) => {
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [borrowedBooks, setBorrowedBooks] = useState<BorrowedBook[]>([]);
  const [adminBorrowings, setAdminBorrowings] = useState<BorrowedBook[]>([]);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [showBorrowingPanel, setShowBorrowingPanel] = useState(false);

  const fetchBorrowed = () => {
    fetchWithRetry(`/api/borrowed/${user.id}`)
      .then(res => res.json())
      .then(setBorrowedBooks)
      .catch(err => console.error("Fetch borrowed error:", err));
  };

  const fetchAdminBorrowings = () => {
    fetchWithRetry('/api/admin/borrowed')
      .then(res => res.json())
      .then(setAdminBorrowings)
      .catch(err => console.error("Fetch admin borrowings error:", err));
  };

  useEffect(() => {
    if (user.role === UserRole.ADMIN) {
      fetchWithRetry('/api/users')
        .then(res => {
          if (!res.ok) throw new Error('Lỗi khi tải danh sách người dùng');
          return res.json();
        })
        .then(setAllUsers)
        .catch(err => console.error("Fetch users error:", err));
      fetchAdminBorrowings();
    }
    fetchBorrowed();
  }, [user]);

  const handleUpdateStatus = async (id: number, status: string) => {
    try {
      const res = await fetchWithRetry(`/api/borrowed/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        fetchBorrowed();
        if (user.role === UserRole.ADMIN) fetchAdminBorrowings();
      }
    } catch (err) {
      console.error("Update status error:", err);
    }
  };

  return (
    <div className="h-full bg-black text-white p-6 overflow-y-auto pb-24">
      <div className="flex justify-between items-start mb-8">
        <div className="flex items-center space-x-4">
          <div className="w-20 h-20 bg-zinc-800 rounded-full flex items-center justify-center border-2 border-zinc-700">
            <UserIcon size={40} />
          </div>
          <div>
            <h1 className="text-2xl font-bold">{user.name}</h1>
            <p className="text-zinc-400 text-sm">{user.email}</p>
            <span className={`inline-block mt-1 px-2 py-0.5 rounded text-[10px] uppercase font-bold ${user.role === UserRole.ADMIN ? 'bg-emerald-500/20 text-emerald-500' : 'bg-zinc-800 text-zinc-500'}`}>
              {user.role === UserRole.ADMIN ? 'Quản trị viên' : 'Thành viên'}
            </span>
          </div>
        </div>
        <button onClick={onLogout} className="p-2 bg-zinc-900 rounded-full text-zinc-400 hover:text-white">
          <LogOut size={20} />
        </button>
      </div>

      <div className="space-y-6">
        {/* Borrowed Books Section */}
        <div className="bg-zinc-900 rounded-2xl p-6 border border-zinc-800">
          <h2 className="text-sm font-bold text-zinc-500 uppercase tracking-widest mb-4">Sách đang mượn</h2>
          {borrowedBooks.length > 0 ? (
            <div className="space-y-4">
              {borrowedBooks.map(b => (
                <div key={b.id} className="flex items-center space-x-4 p-3 bg-black/30 rounded-xl border border-zinc-800/50">
                  <div className="w-12 h-16 bg-zinc-800 rounded overflow-hidden flex-shrink-0">
                    {b.coverUrl && <img src={b.coverUrl} className="w-full h-full object-cover" alt={b.title} />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-sm truncate">{b.title}</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-bold ${
                        b.status === 'pending' ? 'bg-yellow-500/20 text-yellow-500' :
                        b.status === 'borrowed' ? 'bg-emerald-500/20 text-emerald-500' :
                        b.status === 'returning' ? 'bg-blue-500/20 text-blue-500' :
                        'bg-zinc-800 text-zinc-500'
                      }`}>
                        {b.status === 'pending' ? 'Chờ duyệt' : 
                         b.status === 'borrowed' ? 'Đang mượn' : 
                         b.status === 'returning' ? 'Đang trả' : 'Đã trả'}
                      </span>
                      <span className="text-[10px] text-zinc-500 flex items-center">
                        <Clock size={10} className="mr-1" />
                        {new Date(b.borrowDate).toLocaleDateString('vi-VN')}
                      </span>
                    </div>
                  </div>
                  {b.status === 'borrowed' && (
                    <button 
                      onClick={() => handleUpdateStatus(b.id, 'returning')}
                      className="text-[10px] font-bold bg-zinc-800 hover:bg-zinc-700 px-3 py-1.5 rounded-lg transition-colors"
                    >
                      Trả sách
                    </button>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-zinc-500 text-center py-4 italic">Bạn chưa mượn cuốn sách nào</p>
          )}
        </div>

        <div className="bg-zinc-900 rounded-2xl p-6 border border-zinc-800">
          <h2 className="text-sm font-bold text-zinc-500 uppercase tracking-widest mb-4">Thông tin cá nhân</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-zinc-800/50">
              <span className="text-zinc-400 text-sm">Họ và tên</span>
              <span className="font-medium">{user.name}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-zinc-800/50">
              <span className="text-zinc-400 text-sm">Email</span>
              <span className="font-medium">{user.email}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-zinc-800/50">
              <span className="text-zinc-400 text-sm">Số điện thoại</span>
              <span className="font-medium">{user.phone}</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-zinc-400 text-sm">Số CCCD</span>
              <span className="font-medium">{user.cccd}</span>
            </div>
          </div>
        </div>

        {user.role === UserRole.ADMIN && (
          <div className="space-y-4">
            <button 
              onClick={() => setShowBorrowingPanel(!showBorrowingPanel)}
              className="w-full flex items-center justify-between bg-blue-600 text-white font-bold py-4 px-6 rounded-2xl hover:bg-blue-500 transition-colors"
            >
              <div className="flex items-center space-x-2">
                <BookOpen size={20} />
                <span>Quản lý mượn trả</span>
              </div>
              <ChevronRight className={`transition-transform ${showBorrowingPanel ? 'rotate-90' : ''}`} />
            </button>

            <AnimatePresence>
              {showBorrowingPanel && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="bg-zinc-900 rounded-2xl p-6 border border-zinc-800 overflow-hidden"
                >
                  <h2 className="text-sm font-bold text-blue-500 uppercase tracking-widest mb-4">Yêu cầu mượn/trả</h2>
                  <div className="space-y-4">
                    {adminBorrowings.length > 0 ? adminBorrowings.map(b => (
                      <div key={`admin-b-${b.id}`} className="p-4 bg-black/30 rounded-xl border border-zinc-800/50 space-y-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-bold text-sm">{b.title}</p>
                            <p className="text-xs text-zinc-500">Người mượn: {b.userName}</p>
                          </div>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-bold ${
                            b.status === 'pending' ? 'bg-yellow-500/20 text-yellow-500' :
                            b.status === 'borrowed' ? 'bg-emerald-500/20 text-emerald-500' :
                            'bg-blue-500/20 text-blue-500'
                          }`}>
                            {b.status === 'pending' ? 'Chờ mượn' : 
                             b.status === 'borrowed' ? 'Đang mượn' : 'Chờ trả'}
                          </span>
                        </div>
                        <div className="flex space-x-2">
                          {b.status === 'pending' && (
                            <button 
                              onClick={() => handleUpdateStatus(b.id, 'borrowed')}
                              className="flex-1 bg-emerald-500 text-black text-xs font-bold py-2 rounded-lg"
                            >
                              Duyệt mượn
                            </button>
                          )}
                          {b.status === 'returning' && (
                            <button 
                              onClick={() => handleUpdateStatus(b.id, 'returned')}
                              className="flex-1 bg-blue-500 text-white text-xs font-bold py-2 rounded-lg"
                            >
                              Duyệt trả
                            </button>
                          )}
                          <button className="flex-1 bg-zinc-800 text-zinc-400 text-xs font-bold py-2 rounded-lg">
                            Từ chối
                          </button>
                        </div>
                      </div>
                    )) : (
                      <p className="text-sm text-zinc-500 text-center py-4">Không có yêu cầu nào</p>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <button 
              onClick={() => setShowAdminPanel(!showAdminPanel)}
              className="w-full flex items-center justify-between bg-emerald-500 text-black font-bold py-4 px-6 rounded-2xl hover:bg-emerald-400 transition-colors"
            >
              <div className="flex items-center space-x-2">
                <ShieldCheck size={20} />
                <span>Kiểm soát thành viên</span>
              </div>
              <ChevronRight className={`transition-transform ${showAdminPanel ? 'rotate-90' : ''}`} />
            </button>

            <AnimatePresence>
              {showAdminPanel && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="bg-zinc-900 rounded-2xl p-6 border border-zinc-800 overflow-hidden"
                >
                  <h2 className="text-sm font-bold text-emerald-500 uppercase tracking-widest mb-4">Danh sách thành viên</h2>
                  <div className="space-y-4">
                    {allUsers.map(u => (
                      <div key={u.id} className="flex items-center justify-between py-3 border-b border-zinc-800 last:border-0">
                        <div>
                          <p className="font-bold text-sm">{u.name}</p>
                          <p className="text-xs text-zinc-500">{u.email}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-zinc-400">{u.phone}</p>
                          <p className="text-[10px] text-zinc-600">{u.cccd}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
};

const CreatePost = ({ user, onComplete }: { user: User, onComplete: () => void }) => {
  const [description, setDescription] = useState('');
  const [mediaUrl, setMediaUrl] = useState('');
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setPreview(base64String);
        setMediaUrl(base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!mediaUrl) {
      alert("Vui lòng chọn ảnh hoặc video");
      return;
    }
    try {
      const res = await fetchWithRetry('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          mediaUrl: mediaUrl,
          description
        })
      });
      if (res.ok) {
        onComplete();
      } else {
        const data = await res.json();
        alert(data.error || "Lỗi khi đăng bài");
      }
    } catch (err) {
      alert("Lỗi kết nối khi đăng bài");
    }
  };

  return (
    <div className="h-full bg-black text-white p-6 overflow-y-auto pb-24">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold">Tạo bài viết</h1>
        <button onClick={onComplete} className="text-zinc-500">Hủy</button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-zinc-800 rounded-full flex items-center justify-center">
            <UserIcon size={20} />
          </div>
          <div>
            <p className="font-bold text-sm">{user.name}</p>
            <div className="flex items-center space-x-1 bg-zinc-800 px-2 py-0.5 rounded text-[10px] text-zinc-400">
              <span className="w-1 h-1 bg-emerald-500 rounded-full" />
              <span>Công khai</span>
            </div>
          </div>
        </div>

        <textarea
          className="w-full bg-transparent text-lg placeholder:text-zinc-600 focus:outline-none resize-none min-h-[120px]"
          placeholder="Bạn đang nghĩ gì thế?"
          value={description}
          onChange={e => setDescription(e.target.value)}
          required
        />

        <div 
          onClick={() => fileInputRef.current?.click()}
          className="w-full aspect-video bg-zinc-900 border-2 border-dashed border-zinc-800 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:bg-zinc-800/50 transition-colors overflow-hidden relative"
        >
          {preview ? (
            preview.startsWith('data:video/') ? (
              <video src={preview} className="w-full h-full object-cover" controls />
            ) : (
              <img src={preview} className="w-full h-full object-cover" alt="Xem trước" />
            )
          ) : (
            <>
              <ImageIcon size={48} className="text-zinc-700 mb-2" />
              <p className="text-sm text-zinc-500 font-medium">Thêm ảnh hoặc video</p>
            </>
          )}
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept="image/*,video/*" 
            onChange={handleFileChange}
          />
        </div>

        <div className="flex items-center space-x-4 p-4 bg-zinc-900 rounded-2xl border border-zinc-800">
          <p className="text-sm font-bold flex-1">Thêm vào bài viết</p>
          <button type="button" onClick={() => fileInputRef.current?.click()} className="text-emerald-500"><ImageIcon size={24} /></button>
          <button type="button" className="text-blue-500"><Camera size={24} /></button>
        </div>

        <button
          type="submit"
          className="w-full bg-white text-black font-bold py-4 rounded-xl hover:bg-zinc-200 transition-colors shadow-lg shadow-white/5"
        >
          Đăng bài
        </button>
      </form>
    </div>
  );
};

const Inbox = ({ user }: { user: User }) => {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchWithRetry(`/api/notifications/${user.id}`)
      .then(res => {
        if (!res.ok) throw new Error('Lỗi khi tải thông báo');
        return res.json();
      })
      .then(data => {
        setNotifications(data);
        setLoading(false);
      })
      .catch(err => {
        console.error("Fetch notifications error:", err);
        setLoading(false);
      });
  }, [user.id]);

  return (
    <div className="h-full bg-black text-white p-6 overflow-y-auto pb-24">
      <h1 className="text-2xl font-bold mb-6">Hộp thư</h1>
      {loading ? (
        <p className="text-zinc-500 text-center">Đang tải thông báo...</p>
      ) : notifications.length > 0 ? (
        <div className="space-y-4">
          {notifications.map(n => (
            <div key={n.id} className="bg-zinc-900/50 border border-zinc-800 p-4 rounded-2xl flex items-start space-x-4">
              <div className="bg-emerald-500/20 p-2 rounded-full">
                <Bell size={20} className="text-emerald-500" />
              </div>
              <div>
                <p className="text-sm text-zinc-200">{n.message}</p>
                <p className="text-[10px] text-zinc-500 mt-1">{new Date(n.createdAt).toLocaleString('vi-VN')}</p>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center h-64 text-zinc-500">
          <Mail size={48} className="mb-4 opacity-20" />
          <p>Không có thông báo nào</p>
        </div>
      )}
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('home');

  if (!user) {
    return <Auth onLogin={setUser} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'home': return <Feed user={user} />;
      case 'library': return <Library user={user} />;
      case 'inbox': return <Inbox user={user} />;
      case 'profile': return <Profile user={user} onLogout={() => setUser(null)} />;
      case 'post': return <CreatePost user={user} onComplete={() => setActiveTab('home')} />;
      default: return <Feed user={user} />;
    }
  };

  return (
    <div className="h-screen w-full bg-black flex flex-col overflow-hidden font-sans">
      <main className="flex-1 relative overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="h-full w-full"
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>

      <nav className="h-20 bg-black border-t border-zinc-900 flex items-center justify-around px-2 z-50">
        <button 
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center space-y-1 transition-colors ${activeTab === 'home' ? 'text-white' : 'text-zinc-500'}`}
        >
          <HomeIcon size={24} />
          <span className="text-[10px] font-bold">Trang chủ</span>
        </button>
        <button 
          onClick={() => setActiveTab('library')}
          className={`flex flex-col items-center space-y-1 transition-colors ${activeTab === 'library' ? 'text-white' : 'text-zinc-500'}`}
        >
          <LibraryIcon size={24} />
          <span className="text-[10px] font-bold">Thư viện</span>
        </button>
        <button 
          onClick={() => setActiveTab('post')}
          className="flex flex-col items-center group"
        >
          <div className="bg-white rounded-lg p-1 group-hover:scale-110 transition-transform">
            <PlusSquare size={28} className="text-black" />
          </div>
        </button>
        <button 
          onClick={() => setActiveTab('inbox')}
          className={`flex flex-col items-center space-y-1 transition-colors ${activeTab === 'inbox' ? 'text-white' : 'text-zinc-500'}`}
        >
          <Mail size={24} />
          <span className="text-[10px] font-bold">Hộp thư</span>
        </button>
        <button 
          onClick={() => setActiveTab('profile')}
          className={`flex flex-col items-center space-y-1 transition-colors ${activeTab === 'profile' ? 'text-white' : 'text-zinc-500'}`}
        >
          <UserIcon size={24} />
          <span className="text-[10px] font-bold">Hồ sơ</span>
        </button>
      </nav>
    </div>
  );
}
